package com.example.afinal;

public class AboutActivity {
}
