package com.example.afinal;

public class Potion {
    private String name;
    private String description;
    private int price;

    public Potion(String name, String description, int price) {
        this.name = name;
        this.description = description;
        this.price = price;
    }

    // Геттеры и сеттеры
    public String getName() { return name; }
    public String getDescription() { return description; }
    public int getPrice() { return price; }

