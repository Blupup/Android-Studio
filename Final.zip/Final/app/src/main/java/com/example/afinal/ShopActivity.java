package com.example.afinal;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.clickerapp.R;
import com.example.clickerapp.adapters.PotionAdapter;
import com.example.clickerapp.models.Potion;
import java.util.ArrayList;
import java.util.List;

public class ShopActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        RecyclerView potionsRecyclerView = findViewById(R.id.potionsRecyclerView);
        potionsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Potion> potions = new ArrayList<>();
        potions.add(new Potion("Ярость", "Делает 2х клик на 10 минут", 50));
        potions.add(new Potion("Кислота", "Добавляет авто-клик на 5 минут", 75));
        potions.add(new Potion("Святая вода", "Удваивает получаемый опыт на 15 минут", 100));

        PotionAdapter adapter = new PotionAdapter(potions);
        potionsRecyclerView.setAdapter(adapter);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
