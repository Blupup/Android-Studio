package com.example.afinal;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.example.clickerapp.R;
import com.example.clickerapp.utils.PrefsHelper;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        PrefsHelper prefsHelper = new PrefsHelper(this);

        TextView totalEarned = findViewById(R.id.totalEarnedText);
        TextView tasksCompleted = findViewById(R.id.tasksCompletedText);
        TextView upgradesBought = findViewById(R.id.upgradesBoughtText);
        TextView progressText = findViewById(R.id.progressText);

        totalEarned.setText(String.valueOf(prefsHelper.getTotalEarned()));
        tasksCompleted.setText(String.valueOf(prefsHelper.getTasksCompleted()));
        upgradesBought.setText(String.valueOf(prefsHelper.getUpgradesBought()));
        progressText.setText(prefsHelper.getProgress() + "%");
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
