package com.example.afinal;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.example.clickerapp.R;
import com.example.clickerapp.utils.PrefsHelper;

public class SettingsActivity extends AppCompatActivity {

    private PrefsHelper prefsHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        prefsHelper = new PrefsHelper(this);

        Switch soundSwitch = findViewById(R.id.soundSwitch);
        Switch musicSwitch = findViewById(R.id.musicSwitch);
        Switch numberFormatSwitch = findViewById(R.id.numberFormatSwitch);

        soundSwitch.setChecked(prefsHelper.getSoundEnabled());
        musicSwitch.setChecked(prefsHelper.getMusicEnabled());
        numberFormatSwitch.setChecked(prefsHelper.getNumberFormatEnabled());

        soundSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                prefsHelper.setSoundEnabled(isChecked));

        musicSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                prefsHelper.setMusicEnabled(isChecked));

        numberFormatSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                prefsHelper.setNumberFormatEnabled(isChecked));

        findViewById(R.id.resetProgressButton).setOnClickListener(v -> {
            prefsHelper.resetProgress();
            finish();
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
