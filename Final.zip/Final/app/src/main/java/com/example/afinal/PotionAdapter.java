package com.example.afinal;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.clickerapp.R;
import com.example.clickerapp.models.Potion;
import java.util.List;

public class PotionAdapter extends RecyclerView.Adapter<PotionAdapter.PotionViewHolder> {

    private List<Potion> potions;

    public PotionAdapter(List<Potion> potions) {
        this.potions = potions;
    }

    @NonNull
    @Override
    public PotionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_potion, parent, false);
        return new PotionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PotionViewHolder holder, int position) {
        Potion potion = potions.get(position);
        holder.nameText.setText(potion.getName());
        holder.descriptionText.setText(potion.getDescription());
        holder.priceText.setText(String.valueOf(potion.getPrice()));
    }

    @Override
    public int getItemCount() {
        return potions.size();
    }

    static class PotionViewHolder extends RecyclerView.ViewHolder {
        TextView nameText;
        TextView descriptionText;
        TextView priceText;

        public PotionViewHolder(@NonNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.potionNameText);
            descriptionText = itemView.findViewById(R.id.potionDescriptionText);
            priceText = itemView.findViewById(R.id.potionPriceText);
        }
    }
}