package com.example.afinal;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefsHelper {
    private static final String PREFS_NAME = "ClickerPrefs";
    private static final String KEY_SCORE = "score";
    private static final String KEY_CLICK_VALUE = "clickValue";
    private static final String KEY_UPGRADE_COST = "upgradeCost";
    private static final String KEY_SOUND = "sound";
    private static final String KEY_MUSIC = "music";
    private static final String KEY_NUMBER_FORMAT = "numberFormat";
    private static final String KEY_TOTAL_EARNED = "totalEarned";
    private static final String KEY_TASKS_COMPLETED = "tasksCompleted";
    private static final String KEY_UPGRADES_BOUGHT = "upgradesBought";

    private SharedPreferences prefs;

    public PrefsHelper(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void saveGameState(int score, int clickValue, int upgradeCost) {
        prefs.edit()
                .putInt(KEY_SCORE, score)
                .putInt(KEY_CLICK_VALUE, clickValue)
                .putInt(KEY_UPGRADE_COST, upgradeCost)
                .apply();
    }

    public int[] loadGameState() {
        int[] gameState = new int[3];
        gameState[0] = prefs.getInt(KEY_SCORE, 0);
        gameState[1] = prefs.getInt(KEY_CLICK_VALUE, 1);
        gameState[2] = prefs.getInt(KEY_UPGRADE_COST, 10);
        return gameState;
    }

    public boolean getSoundEnabled() {
        return prefs.getBoolean(KEY_SOUND, true);
    }

    public void setSoundEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_SOUND, enabled).apply();
    }

    public boolean getMusicEnabled() {
        return prefs.getBoolean(KEY_MUSIC, true);
    }

    public void setMusicEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_MUSIC, enabled).apply();
    }

    public boolean getNumberFormatEnabled() {
        return prefs.getBoolean(KEY_NUMBER_FORMAT, false);
    }

    public void setNumberFormatEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_NUMBER_FORMAT, enabled).apply();
    }

    public int getTotalEarned() {
        return prefs.getInt(KEY_TOTAL_EARNED, 0);
    }

    public int getTasksCompleted() {
        return prefs.getInt(KEY_TASKS_COMPLETED, 0);
    }

    public int getUpgradesBought() {
        return prefs.getInt(KEY_UPGRADES_BOUGHT, 0);
    }

    public int getProgress() {
        // Логика расчета прогресса
        return 0;
    }

    public void resetProgress() {
        prefs.edit()
                .remove(KEY_SCORE)
                .remove(KEY_CLICK_VALUE)
                .remove(KEY_UPGRADE_COST)
                .remove(KEY_TOTAL_EARNED)
                .remove(KEY_TASKS_COMPLETED)
                .remove(KEY_UPGRADES_BOUGHT)
                .apply();
    }
}
