package com.example.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    private int score = 0;
    private int clickValue = 1;
    private int upgradeCost = 10;
    private TextView scoreText;
    private Button clickButton;
    private PrefsHelper prefsHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        prefsHelper = new PrefsHelper(this);
        loadGameState();

        scoreText = findViewById(R.id.scoreText);
        clickButton = findViewById(R.id.clickButton);

        updateUI();

        clickButton.setOnClickListener(v -> {
            score += clickValue;
            updateUI();
            saveGameState();
        });

        findViewById(R.id.upgradeButton).setOnClickListener(v -> {
            if (score >= upgradeCost) {
                score -= upgradeCost;
                clickValue++;
                upgradeCost = (int) (upgradeCost * 1.5);
                updateUI();
                saveGameState();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        } else if (id == R.id.menu_shop) {
            startActivity(new Intent(this, ShopActivity.class));
            return true;
        } else if (id == R.id.menu_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
            return true;
        } else if (id == R.id.menu_achievements) {
            startActivity(new Intent(this, AchievementsActivity.class));
            return true;
        } else if (id == R.id.menu_potions) {
            startActivity(new Intent(this, PotionsActivity.class));
            return true;
        } else if (id == R.id.menu_about) {
            startActivity(new Intent(this, AboutActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void updateUI() {
        scoreText.setText(String.valueOf(score));
    }

    private void saveGameState() {
        prefsHelper.saveGameState(score, clickValue, upgradeCost);
    }

    private void loadGameState() {
        int[] gameState = prefsHelper.loadGameState();
        score = gameState[0];
        clickValue = gameState[1];
        upgradeCost = gameState[2];
    }
}