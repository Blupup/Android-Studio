package com.example.lab3

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.lab3.ui.theme.Lab3Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Lab3Theme {
                MainScreen()
            }
        }
    }
}

@Composable
fun MainScreen() {
    var distance by remember { mutableStateOf("") }
    var fuelPrice by remember { mutableStateOf("") }
    var fuelConsumption by remember { mutableStateOf("") }

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            TextField(
                value = distance,
                onValueChange = { distance = it },
                label = { Text("Расстояние (км)") }
            )
            Spacer(modifier = Modifier.height(8.dp))
            TextField(
                value = fuelPrice,
                onValueChange = { fuelPrice = it },
                label = { Text("Цена топлива (руб.)") }
            )
            Spacer(modifier = Modifier.height(8.dp))
            TextField(
                value = fuelConsumption,
                onValueChange = { fuelConsumption = it },
                label = { Text("Расход топлива (л/100км)") }
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = {
                val intent = Intent(context, ResultActivity::class.java).apply {
                    putExtra("distance", distance)
                    putExtra("fuelPrice", fuelPrice)
                    putExtra("fuelConsumption", fuelConsumption)
                }
                context.startActivity(intent)
            }) {
                Text("Рассчитать")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = { showHelpDialog() }) {
                Text("?")
            }
        }
    }
}

private fun showHelpDialog() {
    // Здесь можно реализовать диалоговое окно с помощью AlertDialog
}