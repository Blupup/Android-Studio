package com.example.lab5;

import android.animation.ObjectAnimator;
import android.content.res.ColorStateList;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editTextMinutes, editTextSeconds;
    private Button buttonToggle; // Кнопка "Старт/Пауза"
    private ImageView imageViewReset; // ImageView для сброса
    private TextView textViewTimer;
    private ImageView imageViewAnimation;
    private CountDownTimer countDownTimer;
    private MediaPlayer mediaPlayer;
    private long timeLeftInMillis = 0;
    private boolean timerRunning = false;
    private ObjectAnimator rotationAnimator; // Анимация вращения

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Инициализация элементов интерфейса
        editTextMinutes = findViewById(R.id.editTextMinutes);
        editTextSeconds = findViewById(R.id.editTextSeconds);
        buttonToggle = findViewById(R.id.buttonToggle); // Кнопка "Старт/Пауза"
        imageViewReset = findViewById(R.id.imageViewReset); // ImageView для сброса
        textViewTimer = findViewById(R.id.textViewTimer);
        imageViewAnimation = findViewById(R.id.imageViewAnimation);

        // Инициализация анимации вращения
        rotationAnimator = ObjectAnimator.ofFloat(imageViewAnimation, "rotation", 0f, 360f);
        rotationAnimator.setDuration(1000); // 1 секунда на полный оборот
        rotationAnimator.setRepeatCount(ObjectAnimator.INFINITE); // Бесконечное повторение

        // Начальное состояние кнопки "Старт"
        buttonToggle.setEnabled(false); // Кнопка неактивна
        resetButtonColor(); // Устанавливаем "тухлый" цвет

        // Слушатель изменений в полях ввода
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkInput(); // Проверяем ввод при изменении текста
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        editTextMinutes.addTextChangedListener(textWatcher);
        editTextSeconds.addTextChangedListener(textWatcher);

        // Обработка нажатия на кнопку "Старт/Пауза"
        buttonToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (timerRunning) {
                    pauseTimer();
                } else {
                    startTimer();
                }
            }
        });

        // Обработка нажатия на ImageView (кнопка сброса)
        imageViewReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer();
            }
        });
    }

    // Проверка ввода
    private void checkInput() {
        String minutesText = editTextMinutes.getText().toString();
        String secondsText = editTextSeconds.getText().toString();

        // Если введено время, активируем кнопку
        if (!minutesText.isEmpty() || !secondsText.isEmpty()) {
            buttonToggle.setEnabled(true); // Кнопка активна
            buttonToggle.setBackgroundTintList(null); // Яркий цвет (стандартный)
        } else {
            buttonToggle.setEnabled(false); // Кнопка неактивна
            resetButtonColor(); // Возвращаем "тухлый" цвет
        }
    }

    // Запуск таймера
    private void startTimer() {
        String minutesText = editTextMinutes.getText().toString();
        String secondsText = editTextSeconds.getText().toString();

        // Проверка на пустые поля
        if (minutesText.isEmpty() && secondsText.isEmpty()) {
            Toast.makeText(this, "Введите время", Toast.LENGTH_SHORT).show();
            return;
        }

        int minutes = minutesText.isEmpty() ? 0 : Integer.parseInt(minutesText);
        int seconds = secondsText.isEmpty() ? 0 : Integer.parseInt(secondsText);

        // Проверка на нулевое время
        if (minutes == 0 && seconds == 0) {
            Toast.makeText(this, "Время не может быть нулевым", Toast.LENGTH_SHORT).show();
            return;
        }

        timeLeftInMillis = (minutes * 60 + seconds) * 1000;

        // Создание и запуск таймера
        countDownTimer = new CountDownTimer(timeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                updateTimer();
            }

            @Override
            public void onFinish() {
                timerRunning = false;
                buttonToggle.setText("Старт");
                playSound();
                rotationAnimator.pause(); // Остановка анимации
                resetButtonColor(); // Возвращаем стандартный цвет кнопки
            }
        }.start();

        timerRunning = true;
        buttonToggle.setText("Пауза");
        rotationAnimator.start(); // Запуск анимации

        // Устанавливаем зеленый цвет кнопки
        buttonToggle.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, R.color.green)));
    }

    // Пауза таймера
    private void pauseTimer() {
        countDownTimer.cancel();
        timerRunning = false;
        buttonToggle.setText("Старт");
        rotationAnimator.pause(); // Пауза анимации
        // Кнопка остается зеленой
    }

    // Сброс таймера
    private void resetTimer() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        timerRunning = false;
        buttonToggle.setText("Старт");
        timeLeftInMillis = 0;
        updateTimer();

        // Сброс введенного времени в полях EditText
        editTextMinutes.setText(""); // Очистка поля "Минуты"
        editTextSeconds.setText(""); // Очистка поля "Секунды"

        rotationAnimator.end(); // Остановка и сброс анимации
        resetButtonColor(); // Возвращаем стандартный цвет кнопки
        buttonToggle.setEnabled(false); // Кнопка неактивна
    }

    // Возврат кнопки к стандартному цвету
    private void resetButtonColor() {
        buttonToggle.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, com.google.android.material.R.color.mtrl_btn_bg_color_selector)));
    }

    // Обновление отображения таймера
    private void updateTimer() {
        int minutes = (int) (timeLeftInMillis / 1000) / 60;
        int seconds = (int) (timeLeftInMillis / 1000) % 60;

        String timeLeftFormatted = String.format("%02d:%02d", minutes, seconds);
        textViewTimer.setText(timeLeftFormatted);
    }

    // Воспроизведение звука
    private void playSound() {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(this, R.raw.er); // Замените на ваш звуковой файл
        }
        mediaPlayer.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Освобождение ресурсов MediaPlayer
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}